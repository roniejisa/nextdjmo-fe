const Slide = ({ ...props }) => {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path stroke="none" d="M0 0h24v24H0z" fill="none" />
      <path d="M15 6l.01 0" />
      <path d="M3 3m0 3a3 3 0 0 1 3 -3h12a3 3 0 0 1 3 3v8a3 3 0 0 1 -3 3h-12a3 3 0 0 1 -3 -3z" />
      <path d="M3 13l4 -4a3 5 0 0 1 3 0l4 4" />
      <path d="M13 12l2 -2a3 5 0 0 1 3 0l3 3" />
      <path d="M8 21l.01 0" />
      <path d="M12 21l.01 0" />
      <path d="M16 21l.01 0" />
    </svg>
  );
};

export default Slide;
