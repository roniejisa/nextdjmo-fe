const Password = ({ defaultValue, field, item }) => {
  return (
    <input
      type="password"
      name={field.name}
      defaultValue={defaultValue || ""}
      className="w-full outline-outline outline-4 transition border rounded-md p-2"
      autoComplete="off"
    />
  );
};

export default Password;
