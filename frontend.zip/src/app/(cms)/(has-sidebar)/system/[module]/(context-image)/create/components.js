import Bool from "./components/Bool";
import Email from "./components/Email";
import ImageComponent from "./components/Image";
import Text from "./components/Text";
import Password from "./components/Password";
import SelectParent from "./components/SelectParent";
import Editor from "./components/Editor";
import ImageListComponent from "./components/ImageList";
import SelectList from "./components/SelectList";
import Slug from "./components/Slug";
import Repeat from "./components/Repeat";
import DateComponent from "./components/Date";
import Textarea from "./components/Textarea";
import Tab from "./components/Tab";
import Key from "./components/Key";
import FieldType from "./components/FieldType";
import Link from "./components/Link";
import Phone from "./components/Phone";
import Permission from "./components/Permission";
import MultipleCheckbox from "./components/MultipleCheckbox";
import ProductVariant from "./components/ProductVariant";
import Language from "./components/Language";
import PageBuilder from "./components/PageBuilder";
import CodeEditor from "./components/CodeEditor";
import Select from "./components/Select";
import Category from "./components/Category";
import Tag from "./components/Tag";

export const components = {
    text: Text,
    email: Email,
    image: ImageComponent,
    list_image: ImageListComponent,
    bool: Bool,
    password: Password,
    editor: Editor,
    select_parent: SelectParent,
    select_list: SelectList,
    slug: Slug,
    repeat: Repeat,
    date: DateComponent,
    textarea: Textarea,
    tab: Tab,
    key: Key,
    field_type: FieldType,
    link: Link,
    phone: Phone,
    permission: Permission,
    multiple_checkbox: MultipleCheckbox,
    product_variants: ProductVariant,
    language: Language,
    page_builder: PageBuilder,
    code_editor: CodeEditor,
    select: Select,
    category: Category,
    tag:Tag,
}